function [p,t]=Circlerefine
a=0.01;
b=0.04;
h0=a+b;
fd=@(p) sqrt(sum(p.^2,2))-1;
fh=@(p) a+b*(1-sqrt(sum(p.^2,2)));
% Rejection Method
% p(rand<f)
% f=1/(1+b/a(1-|x|)^2);
[p,t]=distmesh2d(fd,fh,h0,[-1,-1;1,1],[]);