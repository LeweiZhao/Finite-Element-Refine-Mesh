function [node,elem,bdFlag]=unirefinecircle(M)
[p,t]=circlemesh(0,0,1,0.5);
tic;
for m=1:M
Nt=size(t,1);   
Np=size(p,1);
px=p(:,1);
py=p(:,2);
et=t;
e=boundedges(p,t);
re=unique(e);
Nre=size(re,1);
bdFlag = setboundary(p,t,'Dirichlet');
Ne=size(e,1);
B=zeros(Ne,3);
B(:,1:2)=e;
BI=zeros(Ne,1);
inpx=zeros(Ne,1);
inpy=zeros(Ne,1);
p1x=px(e(:,1));
p1y=py(e(:,1));
p2x=px(e(:,2));
p2y=py(e(:,2));
for i=1:Ne
et(ismember(et,e(i,:)))=0;
for j=1:Nt
    if sum(et(j,:)==0)>1
        [r,c,v]=find(et(j,:));
            B(i,3)=v;
            inpx(i)=px(v);
            inpy(i)=py(v);
            BI(i)=j;
    end
end
et=t;
end

x1=px(e(:,1));
y1=py(e(:,1));
x2=px(e(:,2));
y2=py(e(:,2));
k=(y2-y1)./(x2-x1);
mx=0.5*(x1+x2);
my=0.5*(y1+y2);
addpx=sign(mx).*sqrt(k.^2./(k.^2+1));
addpy=sign(my).*sqrt(1./(k.^2+1));




[node,elem,bdFlag] = uniformrefine(p,t,bdFlag);
ue=boundedges(node,elem);
rue=unique(ue);
addp=rue(Nre+1:end);
node(addp,:)=[addpx addpy];
p=node;
t=elem;

end
toc;
showmesh(node,elem)
%title('7 times refine')
%n = size(node,1);

%for i = 1:n
    
 % text(node(i,1),node(i,2),num2str(i)); 
    
%end