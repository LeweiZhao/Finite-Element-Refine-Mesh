function [node,elem,bdFlag]=TriRefine(m,lambda)
node=rand(3,2);
elem=[1,2,3];
bdFlag = setboundary(node,elem,'Dirichlet');
for i=1:m
[node,relem,bdFlag] = uniformrefine(node,elem,bdFlag);
node(relem(1,2),:)=(lambda*node(1,:)+node(elem(1,2),:))/(1+lambda);
node(relem(1,3),:)=(lambda*node(1,:)+node(elem(1,3),:))/(1+lambda);
elem=relem
end
showmesh(node,elem);