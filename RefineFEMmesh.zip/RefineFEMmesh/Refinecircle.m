function Refinecircle(M)
[p,t]=circlemesh(0,0,1,0.5);
for m=1:M
Nt=size(t,1);   
Np=size(p,1);
px=p(:,1);
py=p(:,2);
et=t;
e=boundedges(p,t);
Ne=size(e,1);
B=zeros(Ne,3);
B(:,1:2)=e;
BI=zeros(Ne,1);
inpx=zeros(Ne,1);
inpy=zeros(Ne,1);
for i=1:Ne
et(ismember(et,e(i,:)))=0;
for j=1:Nt
    if sum(et(j,:)==0)>1
        [r,c,v]=find(et(j,:));
            B(i,3)=v;
            inpx(i)=px(v);
            inpy(i)=py(v);
            BI(i)=j;
    end
end
et=t;
end

x1=px(e(:,1));
y1=py(e(:,1));
x2=px(e(:,2));
y2=py(e(:,2));
k=(y2-y1)./(x2-x1);
mx=0.5*(x1+x2);
my=0.5*(y1+y2);
addpx=sign(mx).*sqrt(k.^2./(k.^2+1));
addpy=sign(my).*sqrt(1./(k.^2+1));
xo=0.5*(addpx+inpx);
yo=0.5*(addpy+inpy);

tI=1:1:Nt;
tI(BI)='';
IN=size(tI,2);
rN=Nt+3*Ne;
pN=Np+2*Ne;
elem=zeros(rN,3);
Node=zeros(pN,2);
elem(1:IN,:)=t(tI,:);
elem(IN+1:IN+Ne,:)=[B(:,1) B(:,3) (Np+1:1:Np+Ne)'];
elem(IN+Ne+1:IN+2*Ne,:)=[B(:,2) B(:,3) (Np+1:1:Np+Ne)'];
elem(IN+2*Ne+1:IN+3*Ne,:)=[B(:,1) (Np+1:1:Np+Ne)' (Np+Ne+1:1:Np+2*Ne)'];
elem(IN+3*Ne+1:IN+4*Ne,:)=[B(:,2) (Np+1:1:Np+Ne)' (Np+Ne+1:1:Np+2*Ne)'];
Node(1:Np,:)=p;
Node(Np+1:Np+Ne,:)=[xo yo];
Node(Np+Ne+1:end,:)=[addpx addpy];
p=Node;
t=elem;
end
showmesh(Node,elem)
%n = size(Node,1);

%for i = 1:n
    
  % text(Node(i,1),Node(i,2),num2str(i)); 
    
%end