function RefineUnicircle(M)
[p,t]=circlemesh(0,0,1,0.5);
for m=1:M
Nt=size(t,1);   
Np=size(p,1);
px=p(:,1);
py=p(:,2);
et=t;
e=boundedges(p,t);
%enode=unique(e)
Ne=size(e,1);
B=zeros(Ne,3);
B(:,1:2)=e;
BI=zeros(Ne,1);
inpx=zeros(Ne,1);
inpy=zeros(Ne,1);
p1x=px(e(:,1));
p1y=py(e(:,1));
p2x=px(e(:,2));
p2y=py(e(:,2));
for i=1:Ne
et(ismember(et,e(i,:)))=0;
for j=1:Nt
    if sum(et(j,:)==0)>1
        [r,c,v]=find(et(j,:));
            B(i,3)=v;
            inpx(i)=px(v);
            inpy(i)=py(v);
            BI(i)=j;
    end
end
et=t;
end

x1=px(e(:,1));
y1=py(e(:,1));
x2=px(e(:,2));
y2=py(e(:,2));
k=(y2-y1)./(x2-x1);
mx=0.5*(x1+x2);
my=0.5*(y1+y2);
addpx=sign(mx).*sqrt(k.^2./(k.^2+1));
addpy=sign(my).*sqrt(1./(k.^2+1));
x1=0.5*(p1x+inpx);
y1=0.5*(p1y+inpy);
x2=0.5*(p2x+inpx);
y2=0.5*(p2y+inpy);

tI=1:1:Nt;
tI(BI)='';
IN=size(tI,2);
rN=Nt+3*Ne;
pN=Np+3*Ne;
elem=zeros(rN,3);
Node=zeros(pN,2);
tin=t(tI,:)
ten=ismember(tin,e)
[r,c]=find(ten)
len=[r c];
Nr=size(r,1);
Len=zeros(Nr,1);
for i=1:Nr
   Len(i)=tin(r(i),c(i));
end

elem(1:IN,:)=t(tI,:);
elem(IN+1:IN+Ne,:)=[B(:,3) (Np+1:1:Np+Ne)' (Np+Ne+1:1:Np+2*Ne)'];
elem(IN+Ne+1:IN+2*Ne,:)=[B(:,1) (Np+1:1:Np+Ne)' (Np+2*Ne+1:1:Np+3*Ne)'];
elem(IN+2*Ne+1:IN+3*Ne,:)=[B(:,2) (Np+Ne+1:1:Np+2*Ne)' (Np+2*Ne+1:1:Np+3*Ne)'];
elem(IN+3*Ne+1:IN+4*Ne,:)=[(Np+1:1:Np+Ne)' (Np+Ne+1:1:Np+2*Ne)' (Np+2*Ne+1:1:Np+3*Ne)'];
Node(1:Np,:)=p;
Node(Np+1:Np+Ne,:)=[x1 y1];
Node(Np+Ne+1:Np+2*Ne,:)=[x2 y2];
Node(Np+2*Ne+1:end,:)=[addpx addpy];
p=Node;
t=elem;
end
showmesh(Node,elem)
n = size(Node,1);

for i = 1:n
    
   text(Node(i,1),Node(i,2),num2str(i)); 
    
end